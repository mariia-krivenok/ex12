from models import Serializer, ClassSession


class Journal:
    def __init__(self, filename="journal.pkl"):
        self.filename = filename
        self.sessions = Serializer.load_from_file(self.filename)

    def add_session(self, teacher, group, discipline, date):
        session_id = len(self.sessions) + 1
        session = ClassSession(session_id, teacher, group, discipline, date)
        self.sessions.append(session)
        print(f"Добавлено занятие: {session}")

    def save(self):
        Serializer.save_to_file(self.filename, self.sessions)

    def generate_report(self, teacher_id, output_file="teacher_report.txt"):
        """Создать отчет о занятиях преподавателя."""
        report = [session for session in self.sessions if session.teacher.teacher_id == teacher_id]
        with open(output_file, "w", encoding="utf-8") as file:
            file.write(f"Отчет о занятиях преподавателя (ID: {teacher_id}):\n")
            for session in report:
                file.write(str(session) + "\n")
        print(f"Отчет сохранен в {output_file}.")
