from models import Teacher, Group, Discipline
from journal import Journal

journal = Journal()


def main_menu():
    teachers = []
    groups = []
    disciplines = []

    while True:
        print("\nМеню:")
        print("1. Добавить преподавателя")
        print("2. Добавить группу")
        print("3. Добавить дисциплину")
        print("4. Добавить занятие")
        print("5. Сформировать отчет преподавателя")
        print("6. Сохранить данные")
        print("7. Выход")

        choice = input("Выберите действие: ")

        if choice == "1":
            name = input("Введите имя преподавателя: ")
            department = input("Введите кафедру: ")
            teacher_id = len(teachers) + 1
            teacher = Teacher(teacher_id, name, department)
            teachers.append(teacher)
            print(f"Добавлен преподаватель: {teacher}")

        elif choice == "2":
            name = input("Введите название группы: ")
            group_id = len(groups) + 1
            group = Group(group_id, name)
            groups.append(group)
            print(f"Добавлена группа: {group}")

        elif choice == "3":
            name = input("Введите название дисциплины: ")
            discipline_id = len(disciplines) + 1
            discipline = Discipline(discipline_id, name)
            disciplines.append(discipline)
            print(f"Добавлена дисциплина: {discipline}")

        elif choice == "4":
            try:
                teacher_id = int(input("Введите ID преподавателя: "))
                group_id = int(input("Введите ID группы: "))
                discipline_id = int(input("Введите ID дисциплины: "))
                date = input("Введите дату занятия (например, 2024-01-01): ")

                teacher = next(t for t in teachers if t.teacher_id == teacher_id)
                group = next(g for g in groups if g.group_id == group_id)
                discipline = next(d for d in disciplines if d.discipline_id == discipline_id)

                journal.add_session(teacher, group, discipline, date)
            except StopIteration:
                print("Ошибка: один из ID не найден.")

        elif choice == "5":
            teacher_id = int(input("Введите ID преподавателя: "))
            output_file = input("Введите имя файла для отчета (по умолчанию 'teacher_report.txt'): ")
            journal.generate_report(teacher_id, output_file or "teacher_report.txt")

        elif choice == "6":
            journal.save()

        elif choice == "7":
            print("Выход из программы.")
            break

        else:
            print("Неверный выбор. Попробуйте снова.")


if __name__ == "__main__":
    main_menu()
