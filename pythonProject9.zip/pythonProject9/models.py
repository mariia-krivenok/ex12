import pickle


class Teacher:
    def __init__(self, teacher_id, name, department):
        self.teacher_id = teacher_id
        self.name = name
        self.department = department

    def __str__(self):
        return f"[{self.teacher_id}] {self.name} ({self.department})"


class Group:
    def __init__(self, group_id, name):
        self.group_id = group_id
        self.name = name

    def __str__(self):
        return f"[{self.group_id}] {self.name}"


class Discipline:
    def __init__(self, discipline_id, name):
        self.discipline_id = discipline_id
        self.name = name

    def __str__(self):
        return f"[{self.discipline_id}] {self.name}"


class ClassSession:
    def __init__(self, session_id, teacher, group, discipline, date):
        self.session_id = session_id
        self.teacher = teacher
        self.group = group
        self.discipline = discipline
        self.date = date

    def __str__(self):
        return f"Session {self.session_id}: {self.discipline.name} by {self.teacher.name} for {self.group.name} on {self.date}"


class Serializer:
    @staticmethod
    def save_to_file(filename, data):
        """Сохранение данных в файл (сериализация)."""
        with open(filename, "wb") as file:
            pickle.dump(data, file)
        print(f"Данные сохранены в {filename}.")

    @staticmethod
    def load_from_file(filename):
        """Загрузка данных из файла (десериализация)."""
        try:
            with open(filename, "rb") as file:
                return pickle.load(file)
        except FileNotFoundError:
            print(f"Файл {filename} не найден. Возвращаем пустой список.")
            return []
