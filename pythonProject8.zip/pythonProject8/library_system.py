import os
from models import Book, Reader, Loan
class LibrarySystem:
    def __init__(self):
        self.books = []
        self.readers = []
        self.loans = []

    def add_book(self, title, author, genre, year):
        book_id = len(self.books) + 1
        book = Book(book_id, title, author, genre, year)
        self.books.append(book)
        print(f"Книга '{title}' добавлена в систему.")

    def add_reader(self, last_name, first_name, middle_name, card_number):
        reader_id = len(self.readers) + 1
        reader = Reader(reader_id, last_name, first_name, middle_name, card_number)
        self.readers.append(reader)
        print(f"Читатель '{last_name} {first_name}' добавлен в систему.")

    def issue_book(self, reader_id, book_id, loan_date):
        loan = Loan(reader_id, book_id, loan_date)
        self.loans.append(loan)
        print(f"Книга {book_id} выдана читателю {reader_id}.")

    def save_to_file(self):
        """Сохранение всех данных в текстовый файл."""
        filename = "library_report.txt"
        try:
            with open(filename, "w", encoding="utf-8") as file:
                file.write("Книги:\n")
                for book in self.books:
                    file.write(str(book) + "\n")
                file.write("\nЧитатели:\n")
                for reader in self.readers:
                    file.write(str(reader) + "\n")
                file.write("\nВыдачи:\n")
                for loan in self.loans:
                    file.write(str(loan) + "\n")
            print(f"Данные сохранены в файл: {filename}")
        except Exception as e:
            print(f"Ошибка при сохранении данных: {e}")
