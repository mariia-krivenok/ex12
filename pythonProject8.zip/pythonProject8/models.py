class Book:
    def __init__(self, book_id, title, author, genre, year):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.genre = genre
        self.year = year

    def __str__(self):
        return f"[{self.book_id}] {self.title} by {self.author} ({self.genre}, {self.year})"


class Reader:
    def __init__(self, reader_id, last_name, first_name, middle_name, card_number):
        self.reader_id = reader_id
        self.last_name = last_name
        self.first_name = first_name
        self.middle_name = middle_name
        self.card_number = card_number

    def __str__(self):
        return f"[{self.reader_id}] {self.last_name} {self.first_name} {self.middle_name} (Card: {self.card_number})"


class Loan:
    def __init__(self, reader_id, book_id, loan_date):
        self.reader_id = reader_id
        self.book_id = book_id
        self.loan_date = loan_date

    def __str__(self):
        return f"Reader {self.reader_id} borrowed Book {self.book_id} on {self.loan_date}"
