from models import Book, Reader, Loan
from library_system import LibrarySystem

library = LibrarySystem()


def main_menu():
    while True:
        print("\nМеню:")
        print("1. Добавить книгу")
        print("2. Добавить читателя")
        print("3. Выдать книгу")
        print("4. Показать все книги")
        print("5. Показать всех читателей")
        print("6. Показать выдачи")
        print("7. Сохранить в файл")
        print("8. Выход")

        choice = input("Выберите действие: ")

        if choice == "1":
            title = input("Введите название книги: ")
            author = input("Введите автора книги: ")
            genre = input("Введите жанр книги: ")
            year = input("Введите год издания книги: ")
            library.add_book(title, author, genre, year)

        elif choice == "2":
            last_name = input("Введите фамилию читателя: ")
            first_name = input("Введите имя читателя: ")
            middle_name = input("Введите отчество читателя: ")
            card_number = input("Введите номер читательского билета: ")
            library.add_reader(last_name, first_name, middle_name, card_number)

        elif choice == "3":
            reader_id = int(input("Введите ID читателя: "))
            book_id = int(input("Введите ID книги: "))
            loan_date = input("Введите дату выдачи (например, 2024-01-01): ")
            library.issue_book(reader_id, book_id, loan_date)

        elif choice == "4":
            print("\nСписок книг:")
            for book in library.books:
                print(book)

        elif choice == "5":
            print("\nСписок читателей:")
            for reader in library.readers:
                print(reader)

        elif choice == "6":
            print("\nСписок выдач:")
            for loan in library.loans:
                print(loan)

        elif choice == "7":
            library.save_to_file()

        elif choice == "8":
            print("Выход из программы.")
            break

        else:
            print("Неверный выбор. Попробуйте снова.")


if __name__ == "__main__":
    main_menu()
