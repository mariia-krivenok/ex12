from detail import Detail


class Computer:
    def __init__(self):
        """
        Класс для представления компьютера как совокупности деталей.
        """
        self.details = {
            "Процессор": Detail("Процессор", 100),
            "Материнская плата": Detail("Материнская плата", 80),
            "Память": Detail("Память", 60),
        }

    def __str__(self):
        description = "Состав компьютера:\n"
        for name, detail in self.details.items():
            description += f"- {name}: {detail}\n"
        return description

    def add_detail(self, name, performance):
        """
        Добавление или замена детали.
        :param name: Название детали
        :param performance: Производительность
        """
        self.details[name] = Detail(name, performance)
        print(f"Деталь '{name}' добавлена с производительностью {performance}.")

    def upgrade(self, name, new_performance):
        """
        Метод "Модернизация": замена детали на более производительную.
        :param name: Название детали
        :param new_performance: Новая производительность
        """
        if name in self.details:
            old_detail = self.details[name]
            if new_performance > old_detail.performance:
                self.details[name] = Detail(old_detail.name, new_performance)
                print(f"{name} модернизирован. Производительность увеличена до {new_performance}.")
            else:
                print(f"{name} не нуждается в модернизации (производительность уже выше).")
        else:
            print(f"{name} отсутствует в составе компьютера.")

    def repair(self, name):
        """
        Метод "Ремонт": восстановление производительности детали.
        :param name: Название детали
        """
        if name in self.details:
            print(f"{name} успешно отремонтирован.")
        else:
            print(f"{name} отсутствует в составе компьютера.")

    def save_to_file(self, filename):
        """
        Сохранение описания компьютера в текстовый файл.
        :param filename: Имя файла
        """
        with open(filename, "w", encoding="utf-8") as file:
            file.write(str(self))
        print(f"Состав компьютера сохранён в файл '{filename}'.")
