class Detail:
    def __init__(self, name, performance):
        """
        Базовый класс для деталей.
        :param name: Название детали
        :param performance: Производительность детали (целое число)
        """
        self.name = name
        self.performance = performance

    def __str__(self):
        return f"{self.name} (производительность: {self.performance})"
