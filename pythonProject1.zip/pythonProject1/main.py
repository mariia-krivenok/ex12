from computer import Computer

def main():
    pc = Computer()

    while True:
        print("\nМеню:")
        print("1. Просмотреть состав компьютера")
        print("2. Добавить новую деталь")
        print("3. Модернизировать деталь")
        print("4. Отремонтировать деталь")
        print("5. Сохранить описание в файл")
        print("6. Выход")

        choice = input("Выберите действие (1-6): ")

        if choice == "1":
            print("\nТекущий состав компьютера:")
            print(pc)

        elif choice == "2":
            name = input("Введите название новой детали: ")
            performance = int(input("Введите производительность новой детали: "))
            pc.add_detail(name, performance)

        elif choice == "3":
            name = input("Введите название детали для модернизации: ")
            new_performance = int(input("Введите новую производительность: "))
            pc.upgrade(name, new_performance)

        elif choice == "4":
            name = input("Введите название детали для ремонта: ")
            pc.repair(name)

        elif choice == "5":
            filename = input("Введите имя файла для сохранения (например, computer.txt): ")
            pc.save_to_file(filename)

        elif choice == "6":
            print("Выход из программы.")
            break

        else:
            print("Неверный выбор. Попробуйте снова.")


if __name__ == "__main__":
    main()
