class Student:
    def __init__(self, student_id, name, group):
        self.student_id = student_id
        self.name = name
        self.group = group
        self.tasks = []
        self.grades = []

    def __str__(self):
        return f"Student ID: {self.student_id}, Name: {self.name}, Group: {self.group}"

    def __eq__(self, other):
        return self.student_id == other.student_id

    def __len__(self):
        return len(self.tasks)

    def __add__(self, other):
        return Student(self.student_id, self.name, self.group)

    def add_task(self, task):
        self.tasks.append(task)

    def add_grade(self, grade):
        self.grades.append(grade)

    def get_tasks(self):
        return self.tasks

    def get_grades(self):
        return self.grades

    @staticmethod
    def load_students(file_path):
        students = []
        with open(file_path, 'r') as file:
            for line in file:
                student_id, name, group = line.strip().split(';')
                students.append(Student(student_id, name, group))
        return students

    @staticmethod
    def save_students(students, file_path):
        with open(file_path, 'w') as file:
            for student in students:
                file.write(f"{student.student_id};{student.name};{student.group}\n")
