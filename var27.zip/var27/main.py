from student import Student
from group import Group
from organization import Organization
from task import Task
from report import Report

def main():
    students = Student.load_students('students.txt')
    groups = Group.load_groups('groups.txt')
    organizations = Organization.load_organizations('organizations.txt')
    tasks = Task.load_tasks('tasks.txt')
    reports = Report.load_reports('reports.txt')

    while True:
        print("\nМеню:")
        print("1. Показать студентов")
        print("2. Показать группы")
        print("3. Показать организации")
        print("4. Показать задачи")
        print("5. Показать отчеты")
        print("6. Добавить студента")
        print("7. Добавить группу")
        print("8. Добавить организацию")
        print("9. Добавить задачу")
        print("10. Добавить отчет")
        print("11. Сохранить данные")
        print("12. Выйти")

        choice = input("Выберите опцию: ")

        if choice == '1':
            for student in students:
                print(student)
        elif choice == '2':
            for group in groups:
                print(group)
        elif choice == '3':
            for org in organizations:
                print(org)
        elif choice == '4':
            for task in tasks:
                print(task)
        elif choice == '5':
            for report in reports:
                print(report)
        elif choice == '6':
            student_id = input("Введите ID студента: ")
            name = input("Введите имя студента: ")
            group = input("Введите группу студента: ")
            students.append(Student(student_id, name, group))
        elif choice == '7':
            group_id = input("Введите ID группы: ")
            student_ids = input("Введите ID студентов через запятую: ").split(',')
            students_in_group = [Student(student_id, '', '') for student_id in student_ids]
            groups.append(Group(group_id, students_in_group))
        elif choice == '8':
            org_id = input("Введите ID организации: ")
            name = input("Введите название организации: ")
            address = input("Введите адрес организации: ")
            organizations.append(Organization(org_id, name, address))
        elif choice == '9':
            task_id = input("Введите ID задачи: ")
            description = input("Введите описание задачи: ")
            tasks.append(Task(task_id, description))
        elif choice == '10':
            student_id = input("Введите ID студента: ")
            student = next((s for s in students if s.student_id == student_id), None)
            if student:
                task_grades = input("Введите ID задач и оценки через запятую (например, 1;5,2;4): ").split(',')
                tasks_in_report = []
                grades_in_report = []
                for tg in task_grades:
                    task_id, grade = tg.split(';')
                    task = next((t for t in tasks if t.task_id == task_id), None)
                    if task:
                        tasks_in_report.append(task)
                        grades_in_report.append(grade)
                reports.append(Report(student, tasks_in_report, grades_in_report))
            else:
                print("Студент не найден.")
        elif choice == '11':
            Student.save_students(students, 'students_output.txt')
            Group.save_groups(groups, 'groups_output.txt')
            Organization.save_organizations(organizations, 'organizations_output.txt')
            Task.save_tasks(tasks, 'tasks_output.txt')
            Report.save_reports(reports, 'reports_output.txt')
            print("Данные сохранены.")
        elif choice == '12':
            break
        else:
            print("Неверный выбор. Пожалуйста, попробуйте снова.")

if __name__ == "__main__":
    main()
