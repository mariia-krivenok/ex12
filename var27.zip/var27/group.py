from student import Student

class Group:
    def __init__(self, group_id, students):
        self.group_id = group_id
        self.students = students

    def __str__(self):
        return f"Group ID: {self.group_id}, Students: {[student.name for student in self.students]}"

    def __eq__(self, other):
        return self.group_id == other.group_id

    def __len__(self):
        return len(self.students)

    def __add__(self, other):
        return Group(self.group_id, self.students + other.students)

    def add_student(self, student):
        self.students.append(student)

    def get_students(self):
        return self.students

    @staticmethod
    def load_groups(file_path):
        groups = []
        with open(file_path, 'r') as file:
            for line in file:
                group_id, *student_ids = line.strip().split(';')
                students = [Student(student_id, '', '') for student_id in student_ids]
                groups.append(Group(group_id, students))
        return groups

    @staticmethod
    def save_groups(groups, file_path):
        with open(file_path, 'w') as file:
            for group in groups:
                student_ids = ';'.join([student.student_id for student in group.students])
                file.write(f"{group.group_id};{student_ids}\n")
