class Task:
    def __init__(self, task_id, description):
        self.task_id = task_id
        self.description = description

    def __str__(self):
        return f"Task ID: {self.task_id}, Description: {self.description}"

    def __eq__(self, other):
        return self.task_id == other.task_id

    @staticmethod
    def load_tasks(file_path):
        tasks = []
        with open(file_path, 'r') as file:
            for line in file:
                task_id, description = line.strip().split(';')
                tasks.append(Task(task_id, description))
        return tasks

    @staticmethod
    def save_tasks(tasks, file_path):
        with open(file_path, 'w') as file:
            for task in tasks:
                file.write(f"{task.task_id};{task.description}\n")
