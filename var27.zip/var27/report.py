from student import Student
from task import Task

class Report:
    def __init__(self, student, tasks, grades):
        self.student = student
        self.tasks = tasks
        self.grades = grades

    def __str__(self):
        return f"Student: {self.student.name}, Tasks: {[task.description for task in self.tasks]}, Grades: {self.grades}"

    def __eq__(self, other):
        return self.student == other.student

    def __len__(self):
        return len(self.tasks)

    def __add__(self, other):
        return Report(self.student, self.tasks + other.tasks, self.grades + other.grades)

    def get_student(self):
        return self.student

    def get_tasks(self):
        return self.tasks

    def get_grades(self):
        return self.grades

    @staticmethod
    def load_reports(file_path):
        reports = []
        with open(file_path, 'r') as file:
            for line in file:
                student_id, *task_grades = line.strip().split(';')
                student = Student(student_id, '', '')
                tasks = []
                grades = []
                for i in range(0, len(task_grades), 2):
                    task_id = task_grades[i]
                    grade = task_grades[i + 1]
                    tasks.append(Task(task_id, ''))
                    grades.append(grade)
                reports.append(Report(student, tasks, grades))
        return reports

    @staticmethod
    def save_reports(reports, file_path):
        with open(file_path, 'w') as file:
            for report in reports:
                tasks_grades = ';'.join([f"{task.task_id};{grade}" for task, grade in zip(report.tasks, report.grades)])
                file.write(f"{report.student.student_id};{tasks_grades}\n")
