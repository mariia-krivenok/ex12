class Organization:
    def __init__(self, org_id, name, address):
        self.org_id = org_id
        self.name = name
        self.address = address
        self.students = []

    def __str__(self):
        return f"Organization ID: {self.org_id}, Name: {self.name}, Address: {self.address}"

    def __eq__(self, other):
        return self.org_id == other.org_id

    def __len__(self):
        return len(self.students)

    def __add__(self, other):
        return Organization(self.org_id, self.name, self.address)

    def add_student(self, student):
        self.students.append(student)

    def get_students(self):
        return self.students

    @staticmethod
    def load_organizations(file_path):
        organizations = []
        with open(file_path, 'r') as file:
            for line in file:
                org_id, name, address = line.strip().split(';')
                organizations.append(Organization(org_id, name, address))
        return organizations

    @staticmethod
    def save_organizations(organizations, file_path):
        with open(file_path, 'w') as file:
            for org in organizations:
                file.write(f"{org.org_id};{org.name};{org.address}\n")
