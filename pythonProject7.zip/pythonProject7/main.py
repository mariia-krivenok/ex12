from models import Customer, Product, Order
from strategy import DistanceFilterStrategy, StatusFilterStrategy
import os

# Списки клиентов, товаров и заказов
customers = []
products = []
orders = []


def add_customer():
    """Добавление нового клиента"""
    name = input("Введите имя клиента: ")
    address = input("Введите адрес клиента: ")
    distance = float(input("Введите расстояние до клиента (в км): "))
    customer = Customer(name, address, distance)
    customers.append(customer)
    print(f"Клиент {name} добавлен!")


def add_product():
    """Добавление нового товара"""
    id = len(products) + 1
    name = input("Введите название товара: ")
    stock_quantity = int(input("Введите количество товара на складе: "))
    product = Product(id, name, stock_quantity)
    products.append(product)
    print(f"Товар {name} добавлен!")


def add_order():
    """Создание нового заказа"""
    if not customers:
        print("Сначала добавьте хотя бы одного клиента.")
        return
    if not products:
        print("Сначала добавьте хотя бы один товар.")
        return

    print("\nСписок клиентов:")
    for i, customer in enumerate(customers, 1):
        print(f"{i}. {customer}")
    customer_index = int(input("Выберите клиента по номеру: ")) - 1
    customer = customers[customer_index]

    print("\nСписок товаров:")
    for i, product in enumerate(products, 1):
        print(f"{i}. {product}")
    product_indices = input("Введите номера товаров через запятую: ")
    selected_products = [products[int(index) - 1] for index in product_indices.split(",")]

    order_id = len(orders) + 1
    order = Order(order_id, customer, selected_products, customer.distance, "Принят")
    orders.append(order)
    print(f"Заказ {order_id} создан!")


def save_orders_to_file():
    """Сохранение всех заказов в текстовый файл"""
    if not orders:
        print("Нет заказов для сохранения.")
        return

    filename = input("Введите имя файла для сохранения (по умолчанию: orders.txt): ").strip()
    if not filename:
        filename = "orders.txt"

    print(f"Сохраняем файл в директорию: {os.getcwd()}")

    try:
        with open(filename, "w", encoding="utf-8") as file:
            file.write("Список заказов:\n")
            for order in orders:
                file.write(f"Заказ ID: {order.id}\n")
                file.write(f"Клиент: {order.customer.name}, Адрес: {order.customer.address}, Расстояние: {order.distance} км\n")
                file.write("Товары:\n")
                for product in order.products:
                    file.write(f"  - {product.name} (ID: {product.id})\n")
                file.write(f"Статус: {order.status}\n")
                file.write("-" * 40 + "\n")
        print(f"Заказы успешно сохранены в файл: {filename}")
    except Exception as e:
        print(f"Ошибка при сохранении файла: {e}")


def main():
    while True:
        print("\nМеню:")
        print("1. Показать все заказы")
        print("2. Добавить клиента")
        print("3. Добавить товар")
        print("4. Создать заказ")
        print("5. Сохранить заказы в текстовый файл")
        print("6. Выйти")

        choice = input("Выберите действие: ")

        if choice == "1":
            if not orders:
                print("Заказы отсутствуют.")
            else:
                for order in orders:
                    print(order)

        elif choice == "2":
            add_customer()

        elif choice == "3":
            add_product()

        elif choice == "4":
            add_order()

        elif choice == "5":
            save_orders_to_file()

        elif choice == "6":
            print("Выход из программы.")
            break

        else:
            print("Неверный выбор. Попробуйте снова.")


if __name__ == "__main__":
    main()
