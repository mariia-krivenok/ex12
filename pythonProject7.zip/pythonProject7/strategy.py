class DistanceFilterStrategy:
    def __init__(self, max_distance):
        self.max_distance = max_distance

    def filter(self, orders):
        return [order for order in orders if order.distance <= self.max_distance]


class StatusFilterStrategy:
    def __init__(self, status):
        self.status = status

    def filter(self, orders):
        return [order for order in orders if order.status == self.status]
