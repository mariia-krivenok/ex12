class Customer:
    def __init__(self, name, address, distance):
        self.name = name
        self.address = address
        self.distance = distance

    def __str__(self):
        return f"Клиент: {self.name}, адрес: {self.address}, расстояние: {self.distance} км"


class Product:
    def __init__(self, id, name, stock_quantity):
        self.id = id
        self.name = name
        self.stock_quantity = stock_quantity

    def __str__(self):
        return f"Товар: {self.name} (ID: {self.id}, на складе: {self.stock_quantity})"


class Order:
    def __init__(self, id, customer, products, distance, status):
        self.id = id
        self.customer = customer
        self.products = products
        self.distance = distance
        self.status = status

    def __str__(self):
        product_list = ", ".join([product.name for product in self.products])
        return f"Заказ ID: {self.id}, Клиент: {self.customer.name}, Товары: [{product_list}], Статус: {self.status}"
